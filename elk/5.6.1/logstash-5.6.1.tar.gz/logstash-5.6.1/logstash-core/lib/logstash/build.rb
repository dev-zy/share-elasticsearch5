# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-09-14T19:55:30Z", "build_sha"=>"1c7ed904df60c434741e18c8808a2b0caa5bf29d", "build_snapshot"=>false}