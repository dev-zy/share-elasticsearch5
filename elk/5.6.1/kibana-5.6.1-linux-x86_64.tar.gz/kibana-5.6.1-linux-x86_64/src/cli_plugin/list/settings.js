'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.parse = parse;
function parse(command) {
  const settings = {
    pluginDir: command.pluginDir || ''
  };

  return settings;
}
