require('ace/ace.js');
module.exports = window.consoleAce;
