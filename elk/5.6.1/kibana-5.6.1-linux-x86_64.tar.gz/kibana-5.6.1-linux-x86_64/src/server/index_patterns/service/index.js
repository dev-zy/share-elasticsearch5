'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index_patterns_service = require('./index_patterns_service');

Object.defineProperty(exports, 'IndexPatternsService', {
  enumerable: true,
  get: function get() {
    return _index_patterns_service.IndexPatternsService;
  }
});
