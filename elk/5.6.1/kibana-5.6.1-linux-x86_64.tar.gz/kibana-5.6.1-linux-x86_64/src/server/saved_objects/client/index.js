'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _saved_objects_client = require('./saved_objects_client');

Object.defineProperty(exports, 'SavedObjectsClient', {
  enumerable: true,
  get: function get() {
    return _saved_objects_client.SavedObjectsClient;
  }
});
