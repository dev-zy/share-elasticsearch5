"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
const ESC_KEY_CODE = exports.ESC_KEY_CODE = 27;
