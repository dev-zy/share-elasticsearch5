'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mixin = require('./mixin');

Object.defineProperty(exports, 'indexPatternsMixin', {
  enumerable: true,
  get: function get() {
    return _mixin.indexPatternsMixin;
  }
});
