'use strict';

require('../optimize/babel/register');
require('./cli');
