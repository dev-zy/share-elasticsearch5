# encoding: utf-8
BUILD_INFO = {"build_date"=>"2018-04-12T17:54:36Z", "build_sha"=>"ad9bb5fdae1793f22015e04499d3f6d311a67cfb", "build_snapshot"=>false}