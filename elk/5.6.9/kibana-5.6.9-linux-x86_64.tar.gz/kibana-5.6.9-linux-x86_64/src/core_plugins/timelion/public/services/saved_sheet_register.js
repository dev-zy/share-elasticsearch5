define(function () {
  return function savedSearchObjectFn(savedSheets) {
    return savedSheets;
  };
});
