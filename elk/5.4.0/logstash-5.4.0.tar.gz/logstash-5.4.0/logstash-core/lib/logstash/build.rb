# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-04-28T18:14:40Z", "build_sha"=>"0037bc8cf2e9ff169bf5a08b1946c62dbeb92f9b", "build_snapshot"=>false}