# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-08-14T13:11:53Z", "build_sha"=>"e9cbc8a2d8145d0fad86059fb2fcadc693e8c7b0", "build_snapshot"=>false}