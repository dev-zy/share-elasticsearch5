# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-05-29T16:40:20Z", "build_sha"=>"cf39b7a82225994a0a3e716021c66f7a45fae46c", "build_snapshot"=>false}