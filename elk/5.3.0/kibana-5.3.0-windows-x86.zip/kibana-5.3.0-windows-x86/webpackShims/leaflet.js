'use strict';

require('node_modules/leaflet/dist/leaflet.css');
window.L = module.exports = require('node_modules/leaflet/dist/leaflet');

require('node_modules/@spalger/leaflet-heat/dist/leaflet-heat.js');

require('node_modules/@spalger/leaflet-draw/dist/leaflet.draw.css');
require('node_modules/@spalger/leaflet-draw/dist/leaflet.draw.js');
