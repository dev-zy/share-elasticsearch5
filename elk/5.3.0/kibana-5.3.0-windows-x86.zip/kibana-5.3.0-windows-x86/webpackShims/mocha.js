'use strict';

module.exports = require('../node_modules/mocha/mocha.js');
