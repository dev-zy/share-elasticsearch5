# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-03-23T03:56:19Z", "build_sha"=>"da58f0946883e10b4472f6ade80d38b6e02947be", "build_snapshot"=>false}