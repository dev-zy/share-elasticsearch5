# encoding: utf-8
require "logstash/logging/logger"
require "logstash/namespace"
