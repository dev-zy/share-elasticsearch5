export function savedVisualizationProvider(savedVisualizations) {
  return savedVisualizations;
}
