'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const DEFAULT_ESLINT_PATHS = exports.DEFAULT_ESLINT_PATHS = ['Gruntfile.js', 'bin', 'config', 'src', 'scripts', 'tasks', 'test', 'ui_framework/components', 'ui_framework/doc_site', 'utilities'];
