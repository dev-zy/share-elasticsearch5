# encoding: utf-8
BUILD_INFO = {"build_date"=>"2018-02-16T18:10:30+00:00", "build_sha"=>"4ef91a2553c11953e9498776f6756f47a03e74b8", "build_snapshot"=>false}